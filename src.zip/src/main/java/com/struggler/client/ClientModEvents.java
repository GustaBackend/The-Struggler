package com.struggler.client;

import com.struggler.TheStruggler;
import com.struggler.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheStruggler.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // Temporary vanilla humanoid renderer for the first technical smoke test.
        // Replace with an original GeckoLib model and animations in the next milestone.
        event.registerEntityRenderer(ModEntities.MIDLAND_GUARD.get(), ZombieRenderer::new);
    }
}
